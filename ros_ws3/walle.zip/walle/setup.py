from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'walle'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # ("share/walle/launch", ['launch/launchnav.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='sai',
    maintainer_email='no@no.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
		'rover_navigation = walle.obstaclenav:main',
		'obstacle_avoidance = walle.obstaclescan:main'
        ],
    },
)
